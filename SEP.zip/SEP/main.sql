CREATE DATABASE schoolmanagement;
USE schoolmanagement;

CREATE TABLE login(
	id int NOT NULL  AUTO_INCREMENT,
    name CHARACTER(255) NOT NULL,
    username CHARACTER(255) NOT NULL,
    password CHARACTER(255) NOT NULL,
    type CHARACTER(255) NOT NULL ,
    PRIMARY KEY (id)
);

INSERT INTO login (name,username,password,type) VALUES ('kaveena','kaveena','1234','admin');

CREATE TABLE class(
	id int NOT NULL  AUTO_INCREMENT,
    class CHARACTER(255) NOT NULL,
    section CHARACTER(255) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE payment(
	id int NOT NULL  AUTO_INCREMENT,
    name CHARACTER(255) NOT NULL,
    t_id int NOT NULL,
    yr YEAR NOT NULL,
    month CHARACTER(255) NOT NULL,
    amount FLOAT(25) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE teacher(
	id int NOT NULL  AUTO_INCREMENT,
    name CHARACTER(255) NOT NULL,
    sallary CHARACTER(255) NOT NULL,
    mobile CHARACTER(10) NOT NULL,
    address CHARACTER(255) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE fee(
	id int NOT NULL  AUTO_INCREMENT,
    roll CHARACTER(255) NOT NULL,
    name CHARACTER(255) NOT NULL,
    class CHARACTER(255) NOT NULL,
    section CHARACTER(255) NOT NULL,
    yr YEAR NOT NULL,
    month CHARACTER(255) NOT NULL,
    amount FLOAT(25) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE student(
	id int NOT NULL  AUTO_INCREMENT,
    admission CHARACTER(255) NOT NULL,
    name CHARACTER(255) NOT NULL,
    class CHARACTER(255) NOT NULL,
    section CHARACTER(255) NOT NULL,
    roll CHARACTER(255) NOT NULL,
    gender CHARACTER(255) NOT NULL,
    dob CHARACTER(255) NOT NULL,
    fname CHARACTER(255) NOT NULL,
    mname CHARACTER(255) NOT NULL,
    mob CHARACTER(255) NOT NULL,
    address CHARACTER(255) NOT NULL,
    PRIMARY KEY (id)
);
