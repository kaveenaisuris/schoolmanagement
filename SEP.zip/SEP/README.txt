1) Start MYSQL Server
2) Import main.sql for create approciate DB and tables with dummy data
3) Open the Project in netbeans 